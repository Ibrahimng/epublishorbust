<?php

require 'vendor/autoload.php';
require 'CoderSniffUnitTest.php';
